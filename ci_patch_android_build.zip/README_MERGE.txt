CI patch (android_build.yml)

Como usar (no celular mesmo):
1) Vá no seu repositório → Code → Add file → Upload files.
2) Faça upload deste ZIP e confirme para substituir.
3) Entre na aba Actions → Android Build → Run workflow (botão “Run workflow”).
4) Quando terminar, baixe o APK em “Artifacts” (app-debug-apk).

O workflow detecta automaticamente a versão do Android Gradle Plugin no seu projeto
e escolhe um Gradle/JDK compatível, instala o Android SDK, descompacta o seu zip
(AppLockerMVP_camuflado.zip) e compila o APK.

Se o seu projeto não tiver o gradlew/gradle-wrapper.jar, o job gera um wrapper na hora
(usando o Gradle instalado pelo SDKMAN), então não precisa mexer nisso no ZIP.
