package com.example.applockermvp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.applockermvp.databinding.ActivityLockBinding
import com.example.applockermvp.store.LockStore
class LockActivity : AppCompatActivity() {
  companion object { var isShowing: Boolean = false }
  private lateinit var bind: ActivityLockBinding

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    bind = ActivityLockBinding.inflate(layoutInflater)
    setContentView(bind.root)
    isShowing = true

    overridePendingTransition(0, 0)

    bind.btnUnlock.setOnClickListener {
      if (bind.editPin.text.toString() == LockStore.getPin()) finish()
      else bind.editPin.error = "PIN incorreto"
    }

    val canBio = BiometricManager.from(this)
      .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
    if (canBio == BiometricManager.BIOMETRIC_SUCCESS) {
      val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
        object : BiometricPrompt.AuthenticationCallback() {
          override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            finish()
          }
        })
      val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Desbloquear")
        .setSubtitle("Use biometria")
        .setNegativeButtonText("Cancelar")
        .build()
      prompt.authenticate(info)
    }
  }

  override fun onDestroy() {
    super.onDestroy()
    isShowing = false
  }
}


  override fun finish() {
    super.finish()
    overridePendingTransition(0, 0)
    sendBroadcast(android.content.Intent("com.example.applockermvp.ACTION_UNLOCKED"))
  }
