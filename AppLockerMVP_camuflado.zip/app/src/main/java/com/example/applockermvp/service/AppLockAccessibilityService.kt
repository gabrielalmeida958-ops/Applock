package com.example.applockermvp.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent
import com.example.applockermvp.ui.LockActivity
import com.example.applockermvp.store.LockStore
import android.view.*
import android.graphics.PixelFormat
import android.os.Build
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter

class AppLockAccessibilityService : AccessibilityService() {

  private var overlayView: View? = null

  private fun showOverlayAndLock(targetPkg: String) {
    try {
      val wm = getSystemService(WINDOW_SERVICE) as WindowManager
      if (overlayView == null) {
        overlayView = LayoutInflater.from(this).inflate(com.example.applockermvp.R.layout.overlay_block, null)
        val params = WindowManager.LayoutParams(
          WindowManager.LayoutParams.MATCH_PARENT,
          WindowManager.LayoutParams.MATCH_PARENT,
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
          else
            WindowManager.LayoutParams.TYPE_PHONE,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
          PixelFormat.TRANSLUCENT
        )
        wm.addView(overlayView, params)
      }
      val i = Intent(this, LockActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        putExtra("target_pkg", targetPkg)
      }
      startActivity(i)
    } catch (e: Exception) {
      val i = Intent(this, LockActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        putExtra("target_pkg", targetPkg)
      }
      startActivity(i)
    }
  }

  private fun removeOverlay() {
    try {
      val wm = getSystemService(WINDOW_SERVICE) as WindowManager
      overlayView?.let {
        wm.removeView(it)
        overlayView = null
      }
    } catch (_: Exception) {}
  }

  private val unlockReceiver = object: BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
      removeOverlay()
    }
  }

  override fun onServiceConnected() {
    super.onServiceConnected()
    registerReceiver(unlockReceiver, IntentFilter("com.example.applockermvp.ACTION_UNLOCKED"))
  }

  override fun onDestroy() {
    try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
    super.onDestroy()
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent) {
    val pkg = event.packageName?.toString() ?: return
    if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
        event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
      if (LockStore.isLocked(pkg) && !LockActivity.isShowing) {
        showOverlayAndLock(pkg)
      }
    }
  }

  override fun onInterrupt() {}
}
