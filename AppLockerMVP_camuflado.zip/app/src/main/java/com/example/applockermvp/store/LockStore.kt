package com.example.applockermvp.store

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object LockStore {
  private lateinit var prefs: SharedPreferences
  private const val KEY_LOCKED = "locked_list"
  private const val KEY_PIN = "pin_code"

  private var cache: MutableSet<String> = mutableSetOf()

  fun init(ctx: Context) {
    val masterKey = MasterKey.Builder(ctx)
      .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
      .build()
    prefs = EncryptedSharedPreferences.create(
      ctx,
      "applock_prefs",
      masterKey,
      EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
      EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    cache = prefs.getStringSet(KEY_LOCKED, emptySet())?.toMutableSet() ?: mutableSetOf()
  }

  fun isLocked(pkg: String): Boolean = cache.contains(pkg)

  fun toggle(pkg: String) {
    if (cache.contains(pkg)) cache.remove(pkg) else cache.add(pkg)
    prefs.edit().putStringSet(KEY_LOCKED, cache).apply()
  }

  fun all(): Set<String> = cache

  fun setPin(pin: String) { prefs.edit().putString(KEY_PIN, pin).apply() }

  fun getPin(): String = prefs.getString(KEY_PIN, "1234") ?: "1234"
}
