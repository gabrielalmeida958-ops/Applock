package com.example.applockermvp.ui

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.applockermvp.databinding.ActivityMainBinding
import com.example.applockermvp.store.LockStore

class MainActivity : AppCompatActivity() {
  private lateinit var bind: ActivityMainBinding

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    LockStore.init(this)
    bind = ActivityMainBinding.inflate(layoutInflater)
    setContentView(bind.root)

    bind.btnAccessibility.setOnClickListener {
      startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    bind.btnOverlay.setOnClickListener {
      startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
    }

    bind.btnPin.setOnClickListener {
      val newPin = bind.editPin.text.toString().ifBlank { "1234" }
      LockStore.setPin(newPin)
      bind.editPin.setText("")
    }

    val pm = packageManager
    val apps = pm.getInstalledApplications(0)
      .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
      .sortedBy { pm.getApplicationLabel(it).toString() }

    val rv: RecyclerView = bind.recycler
    rv.layoutManager = LinearLayoutManager(this)
    rv.adapter = AppAdapter(apps, pm) { pkg ->
      LockStore.toggle(pkg)
      rv.adapter?.notifyDataSetChanged()
    }
  }
}
