package com.example.applockermvp.ui

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.applockermvp.R
import com.example.applockermvp.store.LockStore

class AppAdapter(
  private val data: List<ApplicationInfo>,
  private val pm: PackageManager,
  private val onToggle: (String) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

  class VH(v: View) : RecyclerView.ViewHolder(v) {
    val icon: ImageView = v.findViewById(R.id.icon)
    val name: TextView = v.findViewById(R.id.name)
    val check: CheckBox = v.findViewById(R.id.check)
  }

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
    val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
    return VH(view)
  }

  override fun getItemCount() = data.size

  override fun onBindViewHolder(holder: VH, position: Int) {
    val app = data[position]
    holder.icon.setImageDrawable(pm.getApplicationIcon(app))
    holder.name.text = pm.getApplicationLabel(app)
    val pkg = app.packageName
    holder.check.isChecked = LockStore.isLocked(pkg)
    holder.itemView.setOnClickListener { onToggle(pkg) }
    holder.check.setOnClickListener { onToggle(pkg) }
  }
}
